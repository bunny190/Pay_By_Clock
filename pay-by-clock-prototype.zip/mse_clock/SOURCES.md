# Sources for the rule pack (all public)

| Rule in rules.py | Source I checked |
|---|---|
| Deduction on sums owed to micro/small enterprises only on actual payment if paid beyond s.15 time limit; inserted by Finance Act 2023 | Rajya Sabha Unstarred Question 242, answered 21 July 2026 (Ministry of Finance) |
| Same rule is s.37(2)(g) of the Income-tax Act 2025, in force from 1 April 2026; FY 2025-26 stays under the 1961 Act | Same reply; explainer on busy.in |
| Time limit: written agreement, never more than 45 days from acceptance; no agreement: 15 days | MSMED Act 2006 s.15, as explained in the Finance Bill memorandum notes and practitioner guides (taxguru.in, itatonline.org digest) |
| Day of acceptance; deemed acceptance; objection within 15 days moves the clock to the day it is removed | MSMED Act 2006 s.15 and s.2, via the same guides |
| Medium enterprises are outside | Same guides; Rajya Sabha reply (micro and small only) |
| Traders: Udyam registration for retail/wholesale traders is for priority-sector lending only, so treated as outside | MSME Ministry office memorandum as summarised by practitioner guides. **A few guides disagree**, so the vendor card lets a CA override. |
| Supplier covered only for supplies on/after Udyam registration | Practitioner guides (taxguru.in). Not tested in court as far as I know. |
| Paying before the return due date does not rescue the deduction for this clause | Finance Bill 2023 memorandum note quoted in the itatonline.org digest |
| Vendor interest under MSMED Act (3 x bank rate, monthly compounding) not deductible | Taxmann analysis of MSMED Act s.16 and s.23 |

I am not a lawyer or a CA. Treat these as study notes, not advice. Check against the statute text before relying on them.
