"""Checks that bad reader output is stopped before it reaches the rules engine (no API needed)."""
import json, rules, extract
cases = {c["id"]: c for c in json.load(open("cases.json"))}
c = cases["C01"]
good = dict(c["gold"]["terms"])
tests = {
  "invented quote":   {**good, "evidence": "within 10 days of dispatch"},
  "low confidence":   {**good, "confidence": 0.5},
  "anchor unclear":   {**good, "anchor": "unclear"},
  "no number":        {**good, "agreed_days": None},
  "good output":      good,
}
for name, t in tests.items():
    p = extract.validate(c, t, c["gold"]["objection"])
    res = rules.evaluate(c, t, c["gold"]["objection"], p)
    print(f"{name:<16} -> {res['status']:<13} {p}")
