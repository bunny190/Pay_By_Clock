"""The 'reader' step. Three ways to fill the same two small forms:
  gold     - the answer a good reader should give (used to test the rules engine alone)
  baseline - simple keyword/regex reader (the non-AI control)
  llm      - OpenRouter free model, temperature 0, JSON only, then validated
The reader never decides a due date, a status or an amount.
"""
import json, os, re, urllib.request
from rules import MIN_CONFIDENCE

ANCHORS = {"acceptance", "delivery", "invoice", "month_end"}


def norm(s):
    return re.sub(r"\s+", " ", s or "").strip().lower()


def gold(case):
    g = case.get("gold", {})
    return g.get("terms"), g.get("objection")


def baseline(case):
    t = case.get("clause_text") or ""
    m = re.search(r"(\d+)\)?\s*(?:calendar\s*)?days", t, re.I) or re.search(r"net\s*(\d+)", t, re.I)
    days = int(m.group(1)) if m else None
    low = t.lower()
    if re.search(r"end of (the )?month|eom", low): anchor = "month_end"
    elif "invoice" in low: anchor = "invoice"
    elif "accept" in low: anchor = "acceptance"
    else: anchor = "delivery"
    if days is None:   # no usable number: treat like "no agreement" (15 days) and never ask a human
        terms = None
    else:
        terms = {"agreed_days": days, "anchor": anchor, "split_terms": False,
                 "evidence": m.group(0), "confidence": 1.0}
    objection = {"objection_raised": False, "objection_removed_on": None, "evidence": "", "confidence": 1.0}
    return terms, objection


TERMS_PROMPT = """You read ONE payment-terms clause from a purchase contract or purchase order.
Return JSON only, no other text:
{"agreed_days": integer or null, "anchor": "acceptance"|"delivery"|"invoice"|"month_end"|"unclear",
 "split_terms": true if more than one payment date or instalment else false,
 "evidence": words copied EXACTLY from the clause, "confidence": number 0 to 1}
Convert number words to digits. If the clause gives no payment period, use null and "unclear".
You know nothing about tax law. Do not calculate dates."""

OBJ_PROMPT = """You read ONE goods-receipt or quality note.
Return JSON only, no other text:
{"objection_raised": true|false|null, "objection_removed_on": "YYYY-MM-DD" or null,
 "evidence": words copied EXACTLY from the note, "confidence": number 0 to 1}
objection_raised is true only for a written complaint or rejection. Use null if you cannot tell.
objection_removed_on is the date the problem was cleared or the goods accepted, if stated.
You know nothing about tax law. Do not calculate dates."""


def _call(system, text):
    key = os.environ["OPENROUTER_API_KEY"]
    model = os.environ.get("OPENROUTER_MODEL", "meta-llama/llama-3.3-70b-instruct:free")
    body = json.dumps({"model": model, "temperature": 0,
                       "messages": [{"role": "system", "content": system},
                                    {"role": "user", "content": text}]}).encode()
    req = urllib.request.Request("https://openrouter.ai/api/v1/chat/completions", body,
                                 {"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    raw = json.load(urllib.request.urlopen(req, timeout=60))["choices"][0]["message"]["content"]
    raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
    return json.loads(raw)


def llm(case):
    terms = obj = None
    if case["doc_type"] in ("contract", "po", "email") and case.get("clause_text"):
        terms = _call(TERMS_PROMPT, case["clause_text"])
    if case.get("objection_text"):
        obj = _call(OBJ_PROMPT, case["objection_text"])
    else:
        obj = {"objection_raised": False, "objection_removed_on": None, "evidence": "", "confidence": 1.0}
    return terms, obj


def validate(case, terms, objection):
    """Guardrails between the reader and the rules engine. Any problem -> human review."""
    problems = []
    if case["doc_type"] == "contract" or case["doc_type"] == "po":
        if not terms:
            problems.append("Reader returned nothing for the payment clause")
        else:
            if terms.get("anchor") not in ANCHORS or terms.get("agreed_days") is None:
                problems.append("Clause does not state a clear payment period")
            if terms.get("confidence", 0) < MIN_CONFIDENCE:
                problems.append(f"Low confidence on clause ({terms.get('confidence')})")
            if norm(terms.get("evidence")) not in norm(case.get("clause_text")) or not terms.get("evidence"):
                problems.append("Evidence quote not found word-for-word in the clause")
    if case.get("objection_text") and objection:
        if objection.get("confidence", 0) < MIN_CONFIDENCE:
            problems.append(f"Low confidence on objection note ({objection.get('confidence')})")
        if norm(objection.get("evidence")) not in norm(case["objection_text"]) or not objection.get("evidence"):
            problems.append("Evidence quote not found word-for-word in the note")
    return problems
