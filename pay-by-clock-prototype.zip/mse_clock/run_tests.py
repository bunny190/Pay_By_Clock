"""Usage: python run_tests.py [gold|baseline|llm]
gold     - feeds the rules engine the answer a good reader should give (tests the code alone)
baseline - keyword reader + same rules engine (the non-AI control)
llm      - OpenRouter free model as reader (needs OPENROUTER_API_KEY; optional OPENROUTER_MODEL)
"""
import json, sys, copy
import extract, rules

mode = sys.argv[1] if len(sys.argv) > 1 else "gold"
cases = json.load(open("cases.json"))
rows, ok = [], 0
for c in cases:
    run = copy.deepcopy(c)
    problems = []
    if mode == "gold":
        terms, obj = extract.gold(c)
        problems = extract.validate(c, terms, obj)
    elif mode == "baseline":
        terms, obj = extract.baseline(c)
        if terms is None and c["doc_type"] in ("contract", "po"):
            run["doc_type"] = "none"      # baseline cannot tell 'no clause' from 'clause I cannot read'
    else:
        terms, obj = extract.llm(c)
        problems = extract.validate(c, terms, obj)
    res = rules.evaluate(run, terms, obj, problems)
    exp = c["expected"]
    good = res["status"] == exp["status"] and res["due_date"] == exp["due_date"]
    ok += good
    rows.append({**res, "expected": exp, "match": good})
    flag = "ok  " if good else "FAIL"
    print(f"{flag} {c['id']} got {res['status']:<32} due {str(res['due_date']):<11} "
          f"expected {exp['status']:<32} due {exp['due_date']}")
print(f"\n{mode}: {ok}/{len(cases)} match (status AND due date)")
json.dump(rows, open(f"results_{mode}.json", "w"), indent=1)
