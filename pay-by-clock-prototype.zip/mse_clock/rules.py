"""Rule pack for the Pay-by Clock prototype.

Plain Python on purpose: a CA should be able to read this file top to bottom.
The AI never calls anything in here and never sees a date calculation.
"""
from datetime import date, timedelta
import calendar

RULE_PACK_VERSION = "2026-11-03"   # bump when the law or its reading changes
CAP_DAYS = 45                      # MSMED Act s.15: written agreement can never go past 45 days
DEFAULT_DAYS = 15                  # MSMED Act s.15: no written agreement -> 15 days
MIN_CONFIDENCE = 0.75


def tax_year_start(d: date) -> int:
    """Indian financial year starts 1 April. 2026-02-10 -> 2025."""
    return d.year if d.month >= 4 else d.year - 1


def year_end(start: int) -> date:
    return date(start + 1, 3, 31)


def law_reference(start: int) -> str:
    # Same rule, new address: Income-tax Act 2025 applies from tax year 2026-27.
    if start <= 2025:
        return "Income-tax Act 1961, s.43B(h) + MSMED Act 2006, s.15"
    return "Income-tax Act 2025, s.37(2)(g) + MSMED Act 2006, s.15"


def month_end(d: date) -> date:
    return date(d.year, d.month, calendar.monthrange(d.year, d.month)[1])


def check_coverage(vendor: dict, supply_date: date):
    """Return (status, reason) if the vendor is outside the rule or needs a human, else None."""
    cls = vendor.get("udyam_class")
    if cls in (None, "none"):
        return "NOT_COVERED_UNREGISTERED", "No Udyam registration on file"
    if cls == "medium":
        return "NOT_COVERED_MEDIUM", "Medium enterprises are outside s.43B(h)"
    if vendor.get("activity") == "trading":
        return "NOT_COVERED_TRADER", "Pure trader: Udyam registration is for priority-sector lending only (CA can override)"
    if vendor.get("activity") == "mixed":
        return "HUMAN_REVIEW", "Vendor does both manufacturing and trading: CA must say which this supply was"
    reg = vendor.get("registered_on")
    if reg and supply_date < date.fromisoformat(reg):
        return "NOT_COVERED_BEFORE_REGISTRATION", f"Supply on {supply_date} is before Udyam registration on {reg}"
    return None


def acceptance_date(delivery: date, objection: dict):
    """Day of acceptance: delivery date, or the day a written objection was cleared."""
    if objection is None or objection.get("objection_raised") is False:
        return delivery, None
    if objection.get("objection_raised") is None:
        return None, "Cannot tell whether an objection was raised"
    if objection.get("objection_removed_on"):
        return date.fromisoformat(objection["objection_removed_on"]), None
    return None, "Objection raised but not yet cleared: the clock has not started"


def evaluate(case: dict, terms: dict, objection: dict, extraction_problems: list):
    """Return one decision dict with a step-by-step trace."""
    trace = []
    delivery = date.fromisoformat(case["delivery_date"])
    invoice = date.fromisoformat(case["invoice_date"])
    paid = date.fromisoformat(case["paid_date"]) if case.get("paid_date") else None
    start = tax_year_start(delivery)
    fy_end = year_end(start)
    out = {"id": case["id"], "law": law_reference(start), "rule_pack": RULE_PACK_VERSION,
           "amount": case["amount"], "status": None, "due_date": None,
           "add_back": 0, "reasons": [], "trace": trace}

    def done(status, why=None):
        out["status"] = status
        if why:
            out["reasons"].append(why)
        return out

    cov = check_coverage(case["vendor"], delivery)
    trace.append(f"Vendor card: {case['vendor']['udyam_class']} / {case['vendor']['activity']}")
    if cov:
        trace.append(f"Coverage: {cov[1]}")
        return done(cov[0], cov[1])

    if extraction_problems:
        trace.append("Reader problems: " + "; ".join(extraction_problems))
        return done("HUMAN_REVIEW", "; ".join(extraction_problems))

    acc, why = acceptance_date(delivery, objection)
    if acc is None:
        trace.append(why)
        return done("HUMAN_REVIEW", why)
    trace.append(f"Day of acceptance: {acc}")

    cap_due = acc + timedelta(days=CAP_DAYS)
    doc_type = case["doc_type"]
    if doc_type == "none":
        due = acc + timedelta(days=DEFAULT_DAYS)
        trace.append(f"No written agreement -> {DEFAULT_DAYS} days from acceptance = {due}")
    elif doc_type == "email":
        return done("HUMAN_REVIEW", "Terms exist only in an email: CA must decide if that is an agreement in writing")
    else:
        if terms.get("split_terms"):
            return done("HUMAN_REVIEW", "Clause has more than one payment date")
        days = terms["agreed_days"]
        anchor = terms["anchor"]
        anchor_date = {"acceptance": acc, "delivery": delivery, "invoice": invoice,
                       "month_end": month_end(invoice)}[anchor]
        agreed_due = anchor_date + timedelta(days=days)
        due = min(agreed_due, cap_due)
        trace.append(f"Contract date: {anchor} {anchor_date} + {days} = {agreed_due}")
        trace.append(f"Law cap: acceptance {acc} + {CAP_DAYS} = {cap_due}")
        trace.append(f"Due date = earlier of the two = {due}")
    out["due_date"] = due.isoformat()

    if paid and paid <= due:
        return done("PAID_ON_TIME")
    if paid and paid <= fy_end:
        return done("PAID_LATE_NO_ADD_BACK",
                    "Paid late but inside the same year: no add-back. Vendor may claim MSMED interest (not deductible).")
    if due > fy_end:
        return done("NOT_DUE_AT_YEAR_END",
                    "Not yet overdue at year end. If it is later paid late, practitioners differ on the year of deduction: CA to decide.")
    out["add_back"] = case["amount"]
    where = f"paid {paid}: deduction moves to that year" if paid else "still unpaid: deduction waits until paid"
    return done("ADD_BACK", f"Overdue at {fy_end}; {where}")
